<?php //include('includes/header.php') ?>
<!-- Begin Page Content -->
<link rel="stylesheet" href="scripts_css/ads_format.css">
<div class="container-fluid">

<h2 class="text-center">Welcome <?php isset($_SESSION['admin'])?"Admin":$_SESSION['user']->fname ?></h2>
<a href="" class="popup">Download</a>
<div class="ads_format1"></div>
<div class="ads_format2"></div>
<div class="ads_format3"></div>
<div class="ads_format4"></div>

</div>
<!-- /.container-fluid -->

<?php //include('includes/footer.php') ?>
<script src="scripts_js/floating_banner.js" async="false"></script>
<script src="scripts_js/popover.js" async="false"></script>
<script src="scripts_js/ads_format1.js" async="false"></script>
<script src="scripts_js/ads_format2.js" async="false"></script>
<script src="scripts_js/ads_format3.js" async="false"></script>
<script src="scripts_js/ads_format4.js" async="false"></script>